package de.derdl1983.weriewas.ml

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.label.ImageLabel
import com.google.mlkit.vision.label.ImageLabeling
import com.google.mlkit.vision.label.defaults.ImageLabelerOptions
import de.derdl1983.weriewas.data.Explanation
import de.derdl1983.weriewas.data.KnowledgeBase
import de.derdl1983.weriewas.data.LabelConfidence
import de.derdl1983.weriewas.util.Images
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Ergebnis der lokalen Analyse: gefundene Labels + fertige Erklärung. */
data class AnalysisResult(val labels: List<LabelConfidence>, val explanation: Explanation)

/**
 * Lokale, offline lauffähige Bilderkennung mit Google ML Kit.
 * Keine Cloud, keine Kosten, keine Anmeldung.
 */
object ImageAnalyzer {

    private const val MIN_CONFIDENCE = 0.35f

    /**
     * Ein gemeinsamer Labeler für alle Analysen. Die Standard-Optionen von ML Kit
     * filtern bereits bei 0,5 – hier bewusst niedriger, damit die eigene
     * Schwelle (MIN_CONFIDENCE) und das Fallback überhaupt greifen können.
     */
    private val labeler by lazy {
        ImageLabeling.getClient(
            ImageLabelerOptions.Builder().setConfidenceThreshold(0.3f).build()
        )
    }

    /** Analysiert das Bild unterhalb des Pfads und liefert Labels + Erklärung. */
    suspend fun analyze(imagePath: String): AnalysisResult {
        // Dekodieren abseits des Main-Threads; die Bitmap wird bewusst nicht recycelt,
        // weil ML Kit bei einem Abbruch der Coroutine noch darauf zugreifen könnte.
        val bitmap: Bitmap = withContext(Dispatchers.Default) { Images.loadThumbnail(imagePath, 1024) }
            ?: throw IllegalStateException("Das Bild konnte nicht gelesen werden.")
        val labels = labelImage(bitmap)
        if (labels.isEmpty()) {
            throw IllegalStateException(
                "Es wurden keine Objekte erkannt. Versuche es mit mehr Licht " +
                    "oder halte die Kamera näher ans Objekt."
            )
        }
        val usable = labels.filter { it.confidence >= MIN_CONFIDENCE }
        val relevant = if (usable.isEmpty()) labels.take(3) else usable
        val explanation = KnowledgeBase.explain(relevant)
        return AnalysisResult(relevant, explanation)
    }

    private suspend fun labelImage(bitmap: Bitmap): List<LabelConfidence> =
        suspendCancellableCoroutine { cont ->
            labeler.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { list: List<ImageLabel> ->
                    cont.resume(list.map { LabelConfidence(it.text, it.confidence) })
                }
                .addOnFailureListener { e ->
                    cont.resumeWithException(
                        IllegalStateException("Die Erkennung ist fehlgeschlagen: " + e.message)
                    )
                }
        }
}
