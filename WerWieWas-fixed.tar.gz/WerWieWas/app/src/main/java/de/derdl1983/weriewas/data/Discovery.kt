package de.derdl1983.weriewas.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.io.File

/** Ein erkanntes Label mit Konfidenz (0..1). */
data class LabelConfidence(val label: String, val confidence: Float)

/** Ein Quellen-/Weiterbildungslink. kind: "wiki" | "youtube-search" | "amazon-search" | "web" */
data class InfoLink(val label: String, val url: String, val kind: String)

/** Strukturierte Erklärung zu einer Entdeckung. */
data class Explanation(
    val title: String,
    val category: String,
    val summary: String,
    val howItWorks: String,
    val usage: String,
    val practical: String,
    val facts: List<String>,
    val safety: String,
    val links: List<InfoLink>,
    val uncertain: Boolean,
    val source: String // "lokal" | "online"
)

/** Eine gespeicherte Entdeckung. */
data class Discovery(
    val id: String,
    val imagePath: String,
    val timestamp: Long,
    val labels: List<LabelConfidence>,
    val explanation: Explanation,
    var isFavorite: Boolean = false
)

/**
 * Einfache JSON-basierte Speicherung der Entdeckungen im App-internen Speicher.
 * Schreibzugriffe sind atomar (Temp-Datei + Umbenennen) und serialisiert; eine
 * beschädigte Datei wird als Sicherung behalten statt stillschweigend überschrieben.
 */
object DiscoveryStore {

    private val lock = Any()

    private fun storeFile(context: Context): File = File(context.filesDir, "discoveries.json")
    private fun backupFile(context: Context): File = File(context.filesDir, "discoveries.json.bak")

    fun loadAll(context: Context): MutableList<Discovery> = synchronized(lock) {
        val file = storeFile(context)
        if (!file.exists()) return@synchronized mutableListOf()
        parseFile(file) ?: run {
            // Hauptdatei unlesbar: beschädigte Datei aufbewahren, Sicherung versuchen
            runCatching { file.copyTo(File(context.filesDir, "discoveries.corrupt.json"), overwrite = true) }
            parseFile(backupFile(context)) ?: mutableListOf()
        }
    }

    /** Liest eine Datei; einzelne defekte Einträge werden übersprungen. Null = Datei insgesamt unlesbar. */
    private fun parseFile(file: File): MutableList<Discovery>? {
        if (!file.exists()) return null
        return try {
            val array = JSONArray(file.readText())
            val result = mutableListOf<Discovery>()
            for (i in 0 until array.length()) {
                try {
                    result.add(discoveryFromJson(array.getJSONObject(i)))
                } catch (e: Exception) {
                    // defekten Eintrag überspringen
                }
            }
            result
        } catch (e: Exception) {
            null
        }
    }

    fun saveAll(context: Context, list: List<Discovery>) {
        synchronized(lock) {
            val file = storeFile(context)
            val tmp = File(context.filesDir, "discoveries.json.tmp")
            try {
                val array = JSONArray()
                list.forEach { array.put(discoveryToJson(it)) }
                tmp.writeText(array.toString())
                if (file.exists()) {
                    runCatching { file.copyTo(backupFile(context), overwrite = true) }
                }
                if (!tmp.renameTo(file)) {
                    tmp.copyTo(file, overwrite = true)
                    tmp.delete()
                }
            } catch (e: Exception) {
                tmp.delete()
            }
        }
    }

    fun add(context: Context, discovery: Discovery): MutableList<Discovery> = synchronized(lock) {
        val list = loadAll(context)
        list.add(0, discovery)
        saveAll(context, list)
        list
    }

    fun get(context: Context, id: String): Discovery? =
        loadAll(context).firstOrNull { it.id == id }

    fun toggleFavorite(context: Context, id: String) {
        synchronized(lock) {
            val list = loadAll(context)
            val d = list.firstOrNull { it.id == id }
            if (d != null) {
                d.isFavorite = !d.isFavorite
                saveAll(context, list)
            }
        }
    }

    fun remove(context: Context, id: String) {
        synchronized(lock) {
            val list = loadAll(context)
            val d = list.firstOrNull { it.id == id }
            if (d != null) {
                File(d.imagePath).delete()
                saveAll(context, list.filter { it.id != id })
            }
        }
    }

    fun clearAll(context: Context) {
        synchronized(lock) {
            val list = loadAll(context)
            list.forEach { File(it.imagePath).delete() }
            saveAll(context, emptyList())
        }
    }

    // --- JSON-Mapping ---

    private fun discoveryToJson(d: Discovery): JSONObject {
        val links = JSONArray()
        d.explanation.links.forEach {
            links.put(JSONObject().put("label", it.label).put("url", it.url).put("kind", it.kind))
        }
        val facts = JSONArray()
        d.explanation.facts.forEach { facts.put(it) }
        val labels = JSONArray()
        d.labels.forEach { labels.put(JSONObject().put("label", it.label).put("conf", it.confidence.toDouble())) }
        val expl = JSONObject()
            .put("title", d.explanation.title)
            .put("category", d.explanation.category)
            .put("summary", d.explanation.summary)
            .put("howItWorks", d.explanation.howItWorks)
            .put("usage", d.explanation.usage)
            .put("practical", d.explanation.practical)
            .put("facts", facts)
            .put("safety", d.explanation.safety)
            .put("links", links)
            .put("uncertain", d.explanation.uncertain)
            .put("source", d.explanation.source)
        return JSONObject()
            .put("id", d.id)
            .put("imagePath", d.imagePath)
            .put("timestamp", d.timestamp)
            .put("labels", labels)
            .put("explanation", expl)
            .put("favorite", d.isFavorite)
    }

    private fun discoveryFromJson(o: JSONObject): Discovery {
        val labels = mutableListOf<LabelConfidence>()
        val labelArray = o.optJSONArray("labels") ?: JSONArray()
        for (i in 0 until labelArray.length()) {
            val jo = labelArray.getJSONObject(i)
            labels.add(LabelConfidence(jo.optString("label"), jo.optDouble("conf", 0.0).toFloat()))
        }
        val e = o.optJSONObject("explanation") ?: JSONObject()
        val facts = mutableListOf<String>()
        val factArray = e.optJSONArray("facts") ?: JSONArray()
        for (i in 0 until factArray.length()) facts.add(factArray.optString(i))
        val links = mutableListOf<InfoLink>()
        val linkArray = e.optJSONArray("links") ?: JSONArray()
        for (i in 0 until linkArray.length()) {
            val jo = linkArray.getJSONObject(i)
            links.add(InfoLink(jo.optString("label"), jo.optString("url"), jo.optString("kind")))
        }
        return Discovery(
            id = o.optString("id"),
            imagePath = o.optString("imagePath"),
            timestamp = o.optLong("timestamp", 0L),
            labels = labels,
            explanation = Explanation(
                title = e.optString("title", "Unbekannt"),
                category = e.optString("category", ""),
                summary = e.optString("summary", ""),
                howItWorks = e.optString("howItWorks", ""),
                usage = e.optString("usage", ""),
                practical = e.optString("practical", ""),
                facts = facts,
                safety = e.optString("safety", ""),
                links = links,
                uncertain = e.optBoolean("uncertain", false),
                source = e.optString("source", "lokal")
            ),
            isFavorite = o.optBoolean("favorite", false)
        )
    }
}
